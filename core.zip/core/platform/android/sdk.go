package android

import (
	"context"
	"fmt"
	"sync"

	nvpclient "github.com/nyxveil/nvp/core/connector"
	"github.com/nyxveil/nvp/core/tunnel"
)

// SDK provides Android VpnService integration surface (called from Kotlin/JNI via gomobile).
type SDK struct {
	mu        sync.Mutex
	mode      tunnel.RouteMode
	connector *nvpclient.Connector
	cpURL     string
}

// NewSDK creates Android client SDK instance.
func NewSDK() *SDK {
	return &SDK{mode: tunnel.RouteAll}
}

// SetRouteMode configures split tunnel policy (platform enforces via VpnService.Builder).
func (s *SDK) SetRouteMode(mode tunnel.RouteMode) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.mode = mode
}

// RouteMode returns current routing mode.
func (s *SDK) RouteMode() tunnel.RouteMode {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.mode
}

// ConnectConfig holds Android connection parameters.
type ConnectConfig struct {
	ControlPlaneURL string
	LicenseToken    string
	DeviceID        string
	LocationID      string
}

// Connect establishes VPN session via Control Plane and NVP core.
func (s *SDK) Connect(ctx context.Context, cfg ConnectConfig) error {
	if cfg.LicenseToken == "" || cfg.DeviceID == "" {
		return fmt.Errorf("license and device_id required")
	}
	if cfg.ControlPlaneURL == "" {
		return fmt.Errorf("control_plane_url required")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.cpURL = cfg.ControlPlaneURL
	s.connector = &nvpclient.Connector{
		CP: nvpclient.NewControlPlaneClient(cfg.ControlPlaneURL),
	}
	valid, err := s.connector.CP.ValidateLicense(ctx, cfg.LicenseToken)
	if err != nil {
		return err
	}
	if valid == nil || !valid.Valid {
		return fmt.Errorf("invalid license")
	}
	return nil
}

// Disconnect closes active session.
func (s *SDK) Disconnect() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.connector = nil
	return nil
}

// ControlPlaneURL returns configured Control Plane base URL after Connect.
func (s *SDK) ControlPlaneURL() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.cpURL
}

// TUNDevice adapts Android ParcelFileDescriptor TUN fd to tunnel.Device.
type TUNDevice struct {
	readFn  func([]byte) (int, error)
	writeFn func([]byte) (int, error)
	closeFn func() error
	mtu     int
	name    string
}

func NewTUNDevice(name string, mtu int, readFn, writeFn func([]byte) (int, error), closeFn func() error) *TUNDevice {
	if mtu <= 0 {
		mtu = 1280
	}
	return &TUNDevice{name: name, mtu: mtu, readFn: readFn, writeFn: writeFn, closeFn: closeFn}
}

func (d *TUNDevice) Read(p []byte) (int, error)  { return d.readFn(p) }
func (d *TUNDevice) Write(p []byte) (int, error) { return d.writeFn(p) }
func (d *TUNDevice) Close() error {
	if d.closeFn != nil {
		return d.closeFn()
	}
	return nil
}
func (d *TUNDevice) MTU() int     { return d.mtu }
func (d *TUNDevice) Name() string { return d.name }
