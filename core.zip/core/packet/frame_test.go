package packet_test

import (
	"testing"

	"github.com/nyxveil/nvp/core/control"
	"github.com/nyxveil/nvp/core/packet"
)

func TestEncodeDecodeInnerPadding(t *testing.T) {
	inner, err := packet.EncodeInner(control.TypeData, []byte("hi"), []byte{9, 9})
	if err != nil {
		t.Fatal(err)
	}
	hdr, payload, pad, err := packet.DecodeInner(inner)
	if err != nil {
		t.Fatal(err)
	}
	if hdr.MsgType != control.TypeData || string(payload) != "hi" || len(pad) != 2 {
		t.Fatalf("roundtrip mismatch: %+v %q %v", hdr, payload, pad)
	}
}

func TestDecodeInnerRejectsFlagMismatch(t *testing.T) {
	data := []byte{control.TypeData, packet.FlagPadding, 0, 0, 1}
	if _, _, _, err := packet.DecodeInner(data); err == nil {
		t.Fatal("padding flag without length must fail")
	}
}
