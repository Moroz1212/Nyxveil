package session

import (
	"testing"
	"time"

	"github.com/nyxveil/nvp/core/keys"
)

func TestApplyKeysResetsSendCountersAndExpiresPrevEpoch(t *testing.T) {
	s := New(DefaultConfig(true))
	sk1, err := keys.DeriveSessionKeys([32]byte{1}, []byte("transcript"), 1)
	if err != nil {
		t.Fatal(err)
	}
	sk2, err := keys.DeriveSessionKeys([32]byte{2}, []byte("transcript"), 2)
	if err != nil {
		t.Fatal(err)
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	if err := s.applyKeysLocked(sk1); err != nil {
		t.Fatal(err)
	}
	s.sendPackets = 100
	s.sendBytes = 9999
	if err := s.applyKeysLocked(sk2); err != nil {
		t.Fatal(err)
	}
	if s.sendPackets != 0 || s.sendBytes != 0 {
		t.Fatalf("counters not reset: packets=%d bytes=%d", s.sendPackets, s.sendBytes)
	}
	if s.prevRecvAEAD == nil || s.prevEpoch != 1 {
		t.Fatal("expected previous-epoch recv keys")
	}
	s.prevDeadline = time.Now().Add(-time.Second)
	if _, _, err := s.recvContextLocked(1); err == nil {
		t.Fatal("expected previous epoch to expire after overlap window")
	}
}
