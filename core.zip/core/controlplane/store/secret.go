package store

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"strings"

	"golang.org/x/crypto/chacha20poly1305"
)

const secretPrefix = "nvp1:"

func parseLicenseKEK(raw string) []byte {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return nil
	}
	if len(raw) == 64 {
		b, err := hex.DecodeString(raw)
		if err == nil && len(b) == chacha20poly1305.KeySize {
			return b
		}
	}
	if len(raw) == chacha20poly1305.KeySize {
		return []byte(raw)
	}
	return nil
}

func (s *Store) wrapSecret(plain string) (string, error) {
	if s == nil || len(s.kek) != chacha20poly1305.KeySize || plain == "" {
		return plain, nil
	}
	aead, err := chacha20poly1305.New(s.kek)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, aead.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return "", err
	}
	ct := aead.Seal(nil, nonce, []byte(plain), []byte("nvp/1/license-secret"))
	out := make([]byte, len(nonce)+len(ct))
	copy(out, nonce)
	copy(out[len(nonce):], ct)
	return secretPrefix + hex.EncodeToString(out), nil
}

func (s *Store) unwrapSecret(stored string) (string, error) {
	if !strings.HasPrefix(stored, secretPrefix) {
		return stored, nil
	}
	if s == nil || len(s.kek) != chacha20poly1305.KeySize {
		return "", fmt.Errorf("license secret is encrypted but NVP_LICENSE_KEK is not set")
	}
	raw, err := hex.DecodeString(strings.TrimPrefix(stored, secretPrefix))
	if err != nil {
		return "", fmt.Errorf("corrupt license secret")
	}
	aead, err := chacha20poly1305.New(s.kek)
	if err != nil {
		return "", err
	}
	ns := aead.NonceSize()
	if len(raw) < ns+aead.Overhead() {
		return "", fmt.Errorf("corrupt license secret")
	}
	pt, err := aead.Open(nil, raw[:ns], raw[ns:], []byte("nvp/1/license-secret"))
	if err != nil {
		return "", fmt.Errorf("license secret decrypt failed")
	}
	return string(pt), nil
}
