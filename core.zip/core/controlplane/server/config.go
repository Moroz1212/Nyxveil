package server

import (
	"crypto/ed25519"
	"crypto/tls"
	"fmt"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/nyxveil/nvp/core/auth/ticket"
	"github.com/nyxveil/nvp/core/controlplane/catalog"
	"github.com/nyxveil/nvp/core/controlplane/model"
)

// TLSConfig holds HTTPS listen configuration.
type TLSConfig struct {
	CertFile string
	KeyFile  string
}

// RateLimitConfig configures per-IP request rate limiting.
type RateLimitConfig struct {
	RequestsPerMinute int
	Burst             int
}

// DefaultRateLimit returns production defaults.
func DefaultRateLimit() RateLimitConfig {
	return RateLimitConfig{RequestsPerMinute: 120, Burst: 30}
}

// ServerOptions configures HTTP serving behavior.
type ServerOptions struct {
	TLS       TLSConfig
	RateLimit RateLimitConfig
}

// Config holds Control Plane server configuration.
type Config struct {
	Issuer        ticket.IssuerConfig
	CatalogSigner catalog.Signer
	Catalog       model.Catalog
	MaxDevices    map[string]int
	Options       ServerOptions
}

// ListenConfig returns tls.Config when cert files are set.
func (o ServerOptions) ListenConfig() (*tls.Config, bool) {
	if o.TLS.CertFile == "" || o.TLS.KeyFile == "" {
		return nil, false
	}
	return &tls.Config{MinVersion: tls.VersionTLS13}, true
}

func startHTTPServer(addr string, handler http.Handler, opts ServerOptions) (*http.Server, error) {
	srv := &http.Server{
		Addr:              addr,
		Handler:           wrapHandler(handler, opts.RateLimit),
		ReadHeaderTimeout: 10 * time.Second,
	}
	var err error
	if _, ok := opts.ListenConfig(); ok {
		err = srv.ListenAndServeTLS(opts.TLS.CertFile, opts.TLS.KeyFile)
	} else {
		err = srv.ListenAndServe()
	}
	return srv, err
}

// PublicKeys returns CP ticket verification keys for VPN nodes.
func PublicKeys(cfg Config) map[string]ed25519.PublicKey {
	return map[string]ed25519.PublicKey{
		cfg.Issuer.KeyID: cfg.Issuer.PrivateKey.Public().(ed25519.PublicKey),
	}
}

// WarnIfInsecure logs when TLS is not configured (dev only).
func WarnIfInsecure(opts ServerOptions) string {
	var msgs []string
	if _, ok := opts.ListenConfig(); !ok {
		msgs = append(msgs, "WARNING: Control Plane listening without TLS — use -cert and -key in production")
	}
	if strings.TrimSpace(os.Getenv("NVP_LICENSE_KEK")) == "" {
		msgs = append(msgs, "WARNING: NVP_LICENSE_KEK unset — license secrets stored in plaintext SQLite")
	}
	return strings.Join(msgs, "\n")
}

func appendUnique(list []string, v string) []string {
	for _, x := range list {
		if x == v {
			return list
		}
	}
	return append(list, v)
}

// MasterAccessRequest grants master role catalog access.
type MasterAccessRequest struct {
	LicenseToken string `json:"license_token"`
	DeviceID     string `json:"device_id"`
}

type MasterAccessResponse struct {
	Role    string `json:"role"`
	Granted bool   `json:"granted"`
}

// NodeDrainRequest toggles node drain state.
type NodeDrainRequest struct {
	NodeID    string `json:"node_id"`
	NodeToken string `json:"node_token"`
	Draining  bool   `json:"draining"`
}

type NodeMaintenanceRequest struct {
	NodeID    string `json:"node_id"`
	NodeToken string `json:"node_token"`
	Enabled   bool   `json:"enabled"`
}

// errNodeAuth is returned for invalid node tokens.
var errNodeAuth = fmt.Errorf("node authentication failed")
