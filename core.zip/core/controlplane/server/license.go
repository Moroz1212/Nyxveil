package server

import (
	"crypto/ed25519"
	"crypto/subtle"
	"net/http"
	"strings"
	"time"

	"github.com/nyxveil/nvp/core/auth/ticket"
	"github.com/nyxveil/nvp/core/controlplane/model"
)

func parseLicenseToken(token string) (id, secret string) {
	id, secret, ok := strings.Cut(token, ":")
	if !ok {
		return token, ""
	}
	return id, secret
}

func licenseIDFromToken(token string) string {
	id, _ := parseLicenseToken(token)
	return id
}

func licenseTokenValid(lic *model.LicenseRecord, token string) bool {
	if lic == nil {
		return false
	}
	id, secret := parseLicenseToken(token)
	if id != lic.LicenseID {
		return false
	}
	if lic.Secret == "" {
		return false
	}
	return subtle.ConstantTimeCompare([]byte(secret), []byte(lic.Secret)) == 1
}

func licenseUsable(lic *model.LicenseRecord) bool {
	return lic != nil && lic.Enabled && !lic.Revoked && !time.Now().After(lic.ExpiresAt)
}

func validDevicePublicKey(pk []byte) bool {
	return len(pk) == ed25519.PublicKeySize
}

func copyFilterNodes(nodes []model.NodeRegistryEntry, role string) []model.NodeRegistryEntry {
	out := make([]model.NodeRegistryEntry, 0, len(nodes))
	for _, n := range nodes {
		if role != "master" && n.TestOnly {
			continue
		}
		out = append(out, n)
	}
	return out
}

func catalogRoleFromRequest(r *http.Request, cfg Config) string {
	h := r.Header.Get("Authorization")
	if !strings.HasPrefix(h, "Bearer ") {
		return "user"
	}
	tok := strings.TrimPrefix(h, "Bearer ")
	claims, err := ticket.Verify(ticket.VerifierConfig{
		Issuer:     cfg.Issuer.Issuer,
		Audience:   cfg.Issuer.Audience,
		PublicKeys: PublicKeys(cfg),
	}, tok, "", "")
	if err != nil || claims.Role != "master" {
		return "user"
	}
	return "master"
}
