package connector_test

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/nyxveil/nvp/core/connector"
	"github.com/nyxveil/nvp/core/controlplane/model"
)

func TestFetchCatalogDoesNotUseRoleQuery(t *testing.T) {
	var gotQuery string
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotQuery = r.URL.RawQuery
		_ = json.NewEncoder(w).Encode(model.SignedCatalog{Catalog: model.Catalog{Version: "1"}})
	}))
	defer ts.Close()

	cp := connector.NewControlPlaneClient(ts.URL)
	if _, err := cp.FetchCatalog(context.Background(), ""); err != nil {
		t.Fatal(err)
	}
	if gotQuery != "" {
		t.Fatalf("catalog request must not use query string, got %q", gotQuery)
	}
}

func TestFetchCatalogSendsBearer(t *testing.T) {
	var gotAuth string
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotAuth = r.Header.Get("Authorization")
		_ = json.NewEncoder(w).Encode(model.SignedCatalog{})
	}))
	defer ts.Close()

	cp := connector.NewControlPlaneClient(ts.URL)
	if _, err := cp.FetchCatalog(context.Background(), "ticket"); err != nil {
		t.Fatal(err)
	}
	if gotAuth != "Bearer ticket" {
		t.Fatalf("auth header: %q", gotAuth)
	}
}
