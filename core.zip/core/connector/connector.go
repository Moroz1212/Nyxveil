package connector

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/nyxveil/nvp/core/auth/ticket"
	"github.com/nyxveil/nvp/core/controlplane/api"
	"github.com/nyxveil/nvp/core/controlplane/model"
	"github.com/nyxveil/nvp/core/failover"
	"github.com/nyxveil/nvp/core/session"
	"github.com/nyxveil/nvp/core/transport"
)

// ControlPlaneClient implements Control Plane HTTP API calls.
type ControlPlaneClient struct {
	BaseURL string
	HTTP    *http.Client
}

// NewControlPlaneClient creates API client.
func NewControlPlaneClient(baseURL string) *ControlPlaneClient {
	return &ControlPlaneClient{
		BaseURL: baseURL,
		HTTP:    &http.Client{Timeout: 15 * time.Second},
	}
}

func (c *ControlPlaneClient) post(ctx context.Context, path string, req, resp any) error {
	body, err := json.Marshal(req)
	if err != nil {
		return err
	}
	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, c.BaseURL+path, bytes.NewReader(body))
	if err != nil {
		return err
	}
	httpReq.Header.Set("Content-Type", "application/json")
	httpResp, err := c.HTTP.Do(httpReq)
	if err != nil {
		return err
	}
	defer httpResp.Body.Close()
	if httpResp.StatusCode >= 400 {
		return fmt.Errorf("control plane %s: status %d", path, httpResp.StatusCode)
	}
	return json.NewDecoder(httpResp.Body).Decode(resp)
}

// ValidateLicense checks license validity.
func (c *ControlPlaneClient) ValidateLicense(ctx context.Context, token string) (*api.LicenseValidateResponse, error) {
	var resp api.LicenseValidateResponse
	err := c.post(ctx, "/api/v1/license/validate", api.LicenseValidateRequest{LicenseToken: token}, &resp)
	return &resp, err
}

// ActivateDevice registers device with Control Plane.
func (c *ControlPlaneClient) ActivateDevice(ctx context.Context, token, deviceID string, pubKey []byte) error {
	var resp api.DeviceActivateResponse
	err := c.post(ctx, "/api/v1/device/activate", api.DeviceActivateRequest{
		LicenseToken: token,
		DeviceID:     deviceID,
		PublicKey:    pubKey,
	}, &resp)
	if err != nil {
		return err
	}
	if !resp.Activated {
		return fmt.Errorf("device activation rejected")
	}
	return nil
}

// IssueTicket requests access ticket for VPN node.
func (c *ControlPlaneClient) IssueTicket(ctx context.Context, token, deviceID, nodeID string) (*api.TicketIssueResponse, error) {
	var resp api.TicketIssueResponse
	err := c.post(ctx, "/api/v1/ticket/issue", api.TicketIssueRequest{
		LicenseToken: token,
		DeviceID:     deviceID,
		NodeID:       nodeID,
	}, &resp)
	return &resp, err
}

// FetchCatalog downloads signed node catalog.
func (c *ControlPlaneClient) FetchCatalog(ctx context.Context, bearerTicket string) (*model.SignedCatalog, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.BaseURL+"/api/v1/catalog", nil)
	if err != nil {
		return nil, err
	}
	if bearerTicket != "" {
		req.Header.Set("Authorization", "Bearer "+bearerTicket)
	}
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("control plane catalog: status %d", resp.StatusCode)
	}
	var signed model.SignedCatalog
	if err := json.NewDecoder(resp.Body).Decode(&signed); err != nil {
		return nil, err
	}
	return &signed, nil
}

// ConnectConfig holds end-to-end client connection parameters.
type ConnectConfig struct {
	LicenseToken     string
	DeviceID         string
	DevicePublicKey  []byte
	DevicePrivateKey ed25519.PrivateKey
	LocationID       string
	Role             string
	CatalogBearer    string
}

// Connector orchestrates CP ticket fetch and transport failover dial.
type Connector struct {
	CP       *ControlPlaneClient
	Registry *transport.Registry
	Policy   failover.ConnectPolicy
	Provider failover.DialConfigProvider
}

// PrepareTicket validates license, activates device if needed, and issues ticket.
func (c *Connector) PrepareTicket(ctx context.Context, cfg ConnectConfig) (string, model.NodeRegistryEntry, error) {
	valid, err := c.CP.ValidateLicense(ctx, cfg.LicenseToken)
	if err != nil {
		return "", model.NodeRegistryEntry{}, err
	}
	if valid == nil || !valid.Valid {
		return "", model.NodeRegistryEntry{}, fmt.Errorf("invalid license")
	}
	if len(cfg.DevicePublicKey) > 0 {
		if err := c.CP.ActivateDevice(ctx, cfg.LicenseToken, cfg.DeviceID, cfg.DevicePublicKey); err != nil {
			return "", model.NodeRegistryEntry{}, err
		}
	}
	signed, err := c.CP.FetchCatalog(ctx, cfg.CatalogBearer)
	if err != nil {
		return "", model.NodeRegistryEntry{}, err
	}
	sel := &failover.Selector{Catalog: signed.Catalog, Role: cfg.Role, LocationID: cfg.LocationID}
	conn, node, err := failover.ConnectWithFailover(ctx, sel, c.Registry, c.Policy, c.Provider)
	if err != nil {
		return "", model.NodeRegistryEntry{}, err
	}
	_ = conn.Close()

	ticketResp, err := c.CP.IssueTicket(ctx, cfg.LicenseToken, cfg.DeviceID, node.NodeID)
	if err != nil {
		return "", model.NodeRegistryEntry{}, err
	}
	return ticketResp.AccessTicket, node, nil
}

// OpenSession dials node, completes handshake, and sends AUTH when a device key is provided.
func (c *Connector) OpenSession(ctx context.Context, cfg ConnectConfig) (*session.Session, transport.Conn, model.NodeRegistryEntry, error) {
	ticketStr, node, err := c.PrepareTicket(ctx, cfg)
	if err != nil {
		return nil, nil, model.NodeRegistryEntry{}, err
	}
	sel := &failover.Selector{Catalog: model.Catalog{Nodes: []model.NodeRegistryEntry{node}}, Role: cfg.Role, LocationID: cfg.LocationID}
	conn, node, err := failover.ConnectWithFailover(ctx, sel, c.Registry, c.Policy, c.Provider)
	if err != nil {
		return nil, nil, model.NodeRegistryEntry{}, err
	}
	sess := session.New(session.DefaultConfig(true))
	if err := sess.Connect(ctx, conn); err != nil {
		conn.Close()
		return nil, nil, model.NodeRegistryEntry{}, err
	}
	if err := sess.RunHandshake(ctx); err != nil {
		conn.Close()
		return nil, nil, model.NodeRegistryEntry{}, err
	}
	if len(cfg.DevicePrivateKey) == ed25519.PrivateKeySize && ticketStr != "" {
		authBody, err := ticket.EncodeAuthPayload(ticketStr, sess.Transcript(), cfg.DevicePrivateKey)
		if err != nil {
			conn.Close()
			return nil, nil, model.NodeRegistryEntry{}, err
		}
		if err := sess.SendAuth(ctx, authBody); err != nil {
			conn.Close()
			return nil, nil, model.NodeRegistryEntry{}, err
		}
	}
	return sess, conn, node, nil
}
