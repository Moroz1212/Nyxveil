package failover

import (
	"testing"
	"time"

	"github.com/nyxveil/nvp/core/controlplane/model"
)

func TestCandidateNodesAllowsUnknownHealth(t *testing.T) {
	sel := &Selector{
		LocationID: "fi-hel",
		Catalog: model.Catalog{
			Nodes: []model.NodeRegistryEntry{
				{NodeID: "a", LocationID: "fi-hel", Enabled: true, Capacity: 10},
				{NodeID: "b", LocationID: "fi-hel", Enabled: true, Capacity: 10, Health: model.HealthInfo{Healthy: false}, LastSeen: time.Now()},
			},
		},
	}
	got := sel.CandidateNodes()
	if len(got) != 1 || got[0].NodeID != "a" {
		t.Fatalf("want only unknown-health node a, got %+v", got)
	}
}
