package integration

import (
	"context"
	"github.com/nyxveil/nvp/core/internal/testutil"
	"github.com/nyxveil/nvp/core/session"
	"github.com/nyxveil/nvp/core/transport/memory"
	"testing"
	"time"
)

func TestChaosSessionSurvivesLoss(t *testing.T) {
	rawClient, rawServer := memory.Pair()

	clientConn := testutil.WrapChaos(rawClient, testutil.ChaosConfig{LossRate: 0.3})
	serverConn := testutil.WrapChaos(rawServer, testutil.ChaosConfig{LossRate: 0.3})

	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	clientSess := session.New(session.DefaultConfig(true))
	serverSess := session.New(session.DefaultConfig(false))

	serverDone := make(chan error, 1)
	go func() {
		_ = serverSess.Connect(ctx, serverConn)
		serverDone <- serverSess.RunHandshake(ctx)
	}()

	if err := clientSess.Connect(ctx, clientConn); err != nil {
		t.Fatal(err)
	}
	handshakeDone := make(chan error, 1)
	go func() { handshakeDone <- clientSess.RunHandshake(ctx) }()
	select {
	case err := <-handshakeDone:
		if err != nil {
			t.Skipf("chaos caused handshake failure (expected in lossy sim): %v", err)
		}
	case <-ctx.Done():
		t.Skip("chaos handshake timed out (expected under packet loss)")
	}
	select {
	case <-serverDone:
	case <-time.After(time.Second):
	}
	cancel()
}

func TestChaosConnDupAndDelay(t *testing.T) {
	rawClient, rawServer := memory.Pair()
	_ = testutil.WrapChaos(rawClient, testutil.ChaosConfig{DupRate: 0.5, Delay: 5 * time.Millisecond, Jitter: 2 * time.Millisecond})
	_ = testutil.WrapChaos(rawServer, testutil.ChaosConfig{ReorderRate: 0.1})

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()

	c1, c2 := memory.Pair()
	s1 := session.New(session.DefaultConfig(true))
	s2 := session.New(session.DefaultConfig(false))

	go func() {
		_ = s2.Connect(ctx, c2)
		_ = s2.RunHandshake(ctx)
	}()
	_ = s1.Connect(ctx, c1)
	_ = s1.RunHandshake(ctx)
	cancel()
}
