package authhandler

import (
	"context"
	"crypto/ed25519"
	"testing"

	"github.com/nyxveil/nvp/core/auth/ticket"
	"github.com/nyxveil/nvp/core/control"
	"github.com/nyxveil/nvp/core/session"
)

func TestAuthHandlerRateLimit(t *testing.T) {
	h := NewAuthHandler("node-1", ticketVerifierStub())
	h.MaxPending = 1

	s1 := session.New(session.DefaultConfig(true))
	s2 := session.New(session.DefaultConfig(true))

	done := make(chan struct{})
	go func() {
		_ = h.HandleAuth(context.Background(), s1, []byte("bad"))
		close(done)
	}()

	err := h.HandleAuth(context.Background(), s2, []byte("bad"))
	if err == nil {
		t.Fatal("expected rate limit")
	}
	<-done
}

func TestAuthHandlerInvalidTicket(t *testing.T) {
	h := NewAuthHandler("node-1", ticketVerifierStub())
	s := session.New(session.DefaultConfig(true))
	err := h.HandleAuth(context.Background(), s, []byte("not-a-jwt"))
	if err == nil {
		t.Fatal("expected error")
	}
}

func ticketVerifierStub() ticket.VerifierConfig {
	return ticket.VerifierConfig{
		Issuer:     "https://x",
		Audience:   "nvp-node",
		PublicKeys: map[string]ed25519.PublicKey{},
		Revoked:    ticket.NopRevocation{},
	}
}

// Ensure auth fail reasons compile.
var _ = control.AuthFailInvalidTicket
