package authhandler

import (
	"context"
	"sync"

	"github.com/nyxveil/nvp/core/auth/ticket"
	"github.com/nyxveil/nvp/core/control"
	"github.com/nyxveil/nvp/core/session"
)

// AuthHandler validates access tickets on VPN nodes.
type AuthHandler struct {
	Verifier   ticket.VerifierConfig
	NodeID     string
	MaxPending int
	pending    int
	mu         sync.Mutex
}

// NewAuthHandler creates node-side auth handler.
func NewAuthHandler(nodeID string, verifier ticket.VerifierConfig) *AuthHandler {
	return &AuthHandler{
		Verifier:   verifier,
		NodeID:     nodeID,
		MaxPending: 256,
	}
}

// HandleAuth validates ticket from AUTH message payload.
func (h *AuthHandler) HandleAuth(ctx context.Context, sess *session.Session, ticketBytes []byte) error {
	h.mu.Lock()
	if h.pending >= h.MaxPending {
		h.mu.Unlock()
		return sess.HandleAuthFail(ctx, control.AuthFailRateLimited)
	}
	h.pending++
	h.mu.Unlock()
	defer func() {
		h.mu.Lock()
		h.pending--
		h.mu.Unlock()
	}()

	jwtStr, sig, err := ticket.SplitAuthPayload(ticketBytes)
	if err != nil {
		_ = sess.HandleAuthFail(ctx, control.AuthFailInvalidTicket)
		return err
	}

	claims, err := ticket.Verify(h.Verifier, jwtStr, "", h.NodeID)
	if err != nil {
		_ = sess.HandleAuthFail(ctx, control.AuthFailInvalidTicket)
		return err
	}
	if err := ticket.VerifySessionBinding(claims, jwtStr, sig, sess.Transcript()); err != nil {
		_ = sess.HandleAuthFail(ctx, control.AuthFailInvalidTicket)
		return err
	}

	_ = claims
	if err := sess.MarkEstablished(); err != nil {
		return err
	}
	return sess.HandleAuthOK(ctx)
}
