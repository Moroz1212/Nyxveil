#!/usr/bin/env bash
# verify-release.sh — fail if release tree has stale/mismatched hashes or
# competing legacy manifest formats.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST="${ROOT}/dist/release"
BIN="${ROOT}/dist/bin"
VERSION="$(tr -d '[:space:]' < "${ROOT}/VERSION")"

die() { echo "verify-release: $*" >&2; exit 1; }
ARTIFACT_ONLY=0
case "${1:-}" in
  --ci-artifact) ARTIFACT_ONLY=1 ;;
  "") ;;
  *) die "unknown verification mode" ;;
esac

echo "==> Frozen Core gate"
bash "${ROOT}/scripts/assert-frozen-core.sh"

echo "==> Release tree present"
[[ -d "${DIST}" ]] || die "missing ${DIST} (run build-release + package-release)"
[[ "${ARTIFACT_ONLY}" -eq 1 || -d "${BIN}" ]] || die "missing ${BIN}"

[[ ! -f "${ROOT}/dist/release-manifest.json" ]] || die "legacy dist/release-manifest.json must not exist"
[[ ! -d "${ROOT}/dist/checksums" ]] || die "stale dist/checksums must not exist"
[[ ! -d "${ROOT}/dist/linux-amd64" ]] || die "stale dist/linux-amd64 must not exist (use dist/release/)"
[[ ! -d "${ROOT}/dist/linux-arm64" ]] || die "stale dist/linux-arm64 must not exist"

REQUIRED=(
  nyxveil-server-linux-amd64
  nyxveilctl-linux-amd64
  nyxveil-catalog-verify-linux-amd64
  nyxveil-server-linux-arm64
  nyxveilctl-linux-arm64
  nyxveil-catalog-verify-linux-arm64
  production-gate.sh
  install.sh
  nyxveil-update.service
  50-nyxveil-management.rules
  VERSION
  THIRD_PARTY_CORE.md
  release-manifest-linux-amd64.json
  release-manifest-linux-arm64.json
  bootstrap-cli-update.sh
  live-final-update.sh
  SHA256SUMS
  UPLOAD-LIST-server-v${VERSION}.txt
)

HASHED=(
  nyxveil-server-linux-amd64
  nyxveilctl-linux-amd64
  nyxveil-catalog-verify-linux-amd64
  nyxveil-server-linux-arm64
  nyxveilctl-linux-arm64
  nyxveil-catalog-verify-linux-arm64
  production-gate.sh
  install.sh
  nyxveil-update.service
  50-nyxveil-management.rules
  VERSION
  THIRD_PARTY_CORE.md
  release-manifest-linux-amd64.json
  release-manifest-linux-arm64.json
  bootstrap-cli-update.sh
  live-final-update.sh
)

echo "==> Required assets"
for f in "${REQUIRED[@]}"; do
  [[ -f "${DIST}/${f}" ]] || die "missing ${DIST}/${f}"
done

echo "==> SHA256SUMS matches every listed file and includes required assets"
(
  cd "${DIST}"
  while read -r hash name; do
    [[ -n "${hash:-}" ]] || continue
    [[ "${hash}" =~ ^[0-9a-fA-F]{64}$ ]] || continue
    name="${name#\*}"
    name="$(basename "${name}")"
    [[ -f "${name}" ]] || die "SHA256SUMS lists missing file ${name}"
    got="$(sha256sum "${name}" | awk '{print $1}')"
    [[ "${got}" == "${hash}" ]] || die "hash mismatch for ${name}: sums=${hash} file=${got}"
  done < SHA256SUMS
  for f in "${HASHED[@]}"; do
    grep -E -q "[[:space:]]\\*?${f}\$" SHA256SUMS || die "SHA256SUMS missing entry for ${f}"
  done
)

echo "==> Staging bin hashes match release flat assets"
if [[ "${ARTIFACT_ONLY}" -eq 0 ]]; then
for f in nyxveil-server-linux-amd64 nyxveilctl-linux-amd64 nyxveil-catalog-verify-linux-amd64 \
         nyxveil-server-linux-arm64 nyxveilctl-linux-arm64 nyxveil-catalog-verify-linux-arm64; do
  a="$(sha256sum "${BIN}/${f}" | awk '{print $1}')"
  b="$(sha256sum "${DIST}/${f}" | awk '{print $1}')"
  [[ "${a}" == "${b}" ]] || die "bin/release mismatch for ${f}"
done

else
  echo "BIN_STAGING_COMPARISON=NOT_EXECUTED (downloaded CI artifact has no build staging)"
fi

echo "==> No CRLF in production shell release assets"
bash "${ROOT}/scripts/assert-no-crlf.sh" \
  "${DIST}/VERSION" \
  "${DIST}/SHA256SUMS" \
  "${DIST}/UPLOAD-LIST-server-v${VERSION}.txt" \
  "${DIST}/NOTES.txt" \
  "${DIST}/bootstrap-cli-update.sh" \
  "${DIST}/live-final-update.sh" \
  "${DIST}/production-gate.sh" \
  "${DIST}/install.sh" \
  "${DIST}/nyxveil-update.service" \
  "${DIST}/50-nyxveil-management.rules" \
  "${DIST}/linux-amd64/scripts" \
  "${DIST}/linux-arm64/scripts" \
  "${DIST}/linux-amd64/installer" \
  "${DIST}/linux-arm64/installer" \
  "${DIST}/linux-amd64/systemd" \
  "${DIST}/linux-arm64/systemd"


echo "==> production-gate.sh parses under bash and is executable"
[[ "${ARTIFACT_ONLY}" -eq 1 || -x "${DIST}/production-gate.sh" ]] || die "production-gate.sh must be executable"
bash -n "${DIST}/production-gate.sh"

echo "==> install.sh parses under bash and is executable"
[[ "${ARTIFACT_ONLY}" -eq 1 || -x "${DIST}/install.sh" ]] || die "install.sh must be executable"
bash -n "${DIST}/install.sh"

echo "==> bootstrap-cli-update.sh parses under bash"
bash -n "${DIST}/bootstrap-cli-update.sh"
bash "${DIST}/bootstrap-cli-update.sh" --help >/dev/null

echo "==> live-final-update.sh parses under bash and is executable"
[[ "${ARTIFACT_ONLY}" -eq 1 || -x "${DIST}/live-final-update.sh" ]] || die "live-final-update.sh must be executable"
bash -n "${DIST}/live-final-update.sh"
bash "${DIST}/live-final-update.sh" --help >/dev/null

echo "==> Manifest asset hashes match release binaries (unsigned ParseManifest)"
go run ./scripts/verify-manifest-hashes.go -dist "${DIST}" -version "${VERSION}"

echo "==> Version consistency"
if ! grep -q "\"${VERSION}\"" "${DIST}/release-manifest-linux-amd64.json"; then
  die "amd64 manifest version != VERSION (${VERSION})"
fi

echo "verify-release: OK version=${VERSION}"
bash "${ROOT}/scripts/check-release-upload-set.sh"
