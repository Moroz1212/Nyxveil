# Networking

## Listeners

| Transport | Default | Config key |
|-----------|---------|------------|
| TLS (TCP) | `:443` | `tls_listen` |
| QUIC (UDP) | `:443` | `quic_listen` |

Installer flags `--tls-port` / `--quic-port` write these listen addresses.

`public_host` (or `--public-ip` when host omitted) is advertised to Control Plane as an endpoint during register.

## TUN datapath

- Interface name: `nyxveil0`
- Node address: first usable address in `vpn_subnet_cidr` (default `10.66.0.0/24`)
- Requires `/dev/net/tun` and `CAP_NET_ADMIN`
- Sysctl: `net.ipv4.ip_forward=1` via `/etc/sysctl.d/99-nyxveil.conf`

## NAT

Client subnet is masqueraded on egress through the host’s uplink using nftables table `inet nyxveil` chain `postrouting`. See [FIREWALL.md](FIREWALL.md).

## Control socket

- Linux: Unix socket `/run/nyxveil/control.sock`
- Used by `nyxveilctl status|health`
- Not exposed on the public network

## Ports to allow inbound

- TCP `tls-port` (default 443)
- UDP `quic-port` (default 443)
- Outbound HTTPS to Control Plane

Do not expose the control socket or SSH alternatives via Nyxveil config.
