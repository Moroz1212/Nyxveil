# Install

Target: **Ubuntu 24.04**, **systemd**, **amd64 or arm64**, **nftables**. No Docker. No `go build` on the VPS.

## Prerequisites

- Root (`sudo`)
- `/dev/net/tun` available
- Outbound HTTPS to Control Plane
- ~700MB+ RAM recommended (installer warns below that)
- ≥200MB free on `/var` or `/`

## Interactive (recommended)

```bash
curl -fsSL https://raw.githubusercontent.com/Moroz1212/Nyxveil/main/server/installer/install.sh | sudo bash
```

Prompts (token via `read -s`):

- Control Plane URL
- Location ID
- Display name
- Bootstrap token

## Flagged install

```bash
sudo bash install.sh \
  --control-plane https://control.example.com \
  --location hel-1 \
  --name hel-edge-01 \
  --bootstrap-token "$TOKEN" \
  --public-host vpn.example.com \
  --tls-port 443 \
  --quic-port 443
```

## Offline / air-gapped

On a build host:

```bash
cd server
bash scripts/build-release.sh
bash scripts/package-release.sh
```

Copy `dist/release/linux-amd64` (or arm64) to the VPS:

```bash
sudo ./installer/install.sh --binary-dir . --skip-download \
  --control-plane https://control.example.com \
  --location hel-1 \
  --name hel-edge-01 \
  --bootstrap-token "$TOKEN"
```

## What the installer does

1. Validates OS, systemd PID 1, arch, TUN, RAM/disk
2. `apt` installs only missing: `nftables`, `iproute2`, `ca-certificates`, `curl`
3. Creates user `nyxveil` and directories
4. Installs binaries to `/usr/local/sbin`
5. Writes `sysctl.d/99-nyxveil.conf` (`ip_forward=1`)
6. Applies **only** nftables table `inet nyxveil` (never flushes ruleset)
7. Writes `/etc/nyxveil/server.json` **without** the token
8. Runs `nyxveil-server --register TOKEN`
9. Enables and starts systemd; self-tests via `nyxveilctl health`
10. **COMMIT** — EXIT trap no longer rolls back

On failure before COMMIT, the EXIT trap restores prior binaries/unit/config and removes incomplete state. Repair preserves `node.key` and `node_id`.

## Uninstall

```bash
sudo ./installer/uninstall.sh              # keep state
sudo ./installer/uninstall.sh --purge-state --purge-user
```

## After install

```bash
serv_status
serv_health
serv_logs -f
```
