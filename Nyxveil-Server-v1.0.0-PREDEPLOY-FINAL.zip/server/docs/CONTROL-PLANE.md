# Control Plane

The node is a **client** of the Nyxveil Control Plane.

## Registration

Bootstrap (installer):

```bash
nyxveil-server --config /etc/nyxveil/server.json --register "$BOOTSTRAP_TOKEN"
```

Sends `POST /api/v1/nodes/register` with:

- `bootstrap_token` (one-time; not stored on disk)
- `node_id`, `location_id`, `display_name`
- Ed25519 `public_key` / `public_identity` from `node.key`
- Optional `public_host` endpoint(s)

Response updates operational awareness (`node_id`, `config_version`). Local `server.json` already holds the chosen `node_id`.

## Ongoing APIs (signed)

After registration, requests use **nvp-node-req-v2** headers (`internal/nodeauth`):

| Method | Path | Purpose |
|--------|------|---------|
| POST | `/api/v1/nodes/{id}/health` | Heartbeat / load |
| GET | `/api/v1/node/config` | Desired node config |
| GET | `/api/v1/revocation` | Revocation snapshot |

## Local config fields

`/etc/nyxveil/server.json` (no secrets):

- `control_plane_url`
- `node_id`, `location_id`, `display_name`
- `public_host`, `tls_listen`, `quic_listen`
- `vpn_subnet_cidr` (default `10.66.0.0/24`)
- `heartbeat_seconds`

Applied CP config snapshot (if any): `/var/lib/nyxveil/applied-config.json`.

## Operator checks

```bash
nyxveilctl status   # includes cp_connected
nyxveilctl health
```
