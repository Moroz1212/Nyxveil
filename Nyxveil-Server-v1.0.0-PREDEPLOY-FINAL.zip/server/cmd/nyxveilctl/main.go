package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"github.com/nyxveil/server/internal/paths"
	"github.com/nyxveil/server/internal/version"
)

func main() {
	if len(os.Args) < 2 {
		usage()
		os.Exit(2)
	}
	cmd := os.Args[1]
	args := os.Args[2:]
	var err error
	switch cmd {
	case "version":
		fmt.Printf("nyxveilctl %s (server %s, core %s, %s)\n",
			version.ServerVersion, version.ServerVersion, version.CoreVersion, version.ProtocolVersion)
	case "status":
		err = printJSON("/status")
	case "health":
		err = printJSON("/health")
	case "start":
		err = systemctl("start", "nyxveil-server")
	case "stop":
		err = systemctl("stop", "nyxveil-server")
	case "restart":
		err = systemctl("restart", "nyxveil-server")
	case "logs":
		err = journalctl(args)
	case "update":
		err = runUpdate(args)
	case "config":
		err = showConfig(args)
	case "uninstall":
		err = uninstall()
	case "help", "-h", "--help":
		usage()
	default:
		fmt.Fprintf(os.Stderr, "unknown command %q\n", cmd)
		usage()
		os.Exit(2)
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		os.Exit(1)
	}
}

func usage() {
	fmt.Fprintf(os.Stderr, `nyxveilctl — Nyxveil VPN node control

Usage:
  nyxveilctl status
  nyxveilctl health
  nyxveilctl start|stop|restart
  nyxveilctl logs [-f]
  nyxveilctl update <manifest-url>
  nyxveilctl config [path]
  nyxveilctl version
  nyxveilctl uninstall
`)
}

func controlBase() string {
	if v := os.Getenv("NYXVEIL_CONTROL_HTTP"); v != "" {
		return strings.TrimRight(v, "/")
	}
	if runtime.GOOS == "windows" {
		return "http://127.0.0.1:9797"
	}
	return ""
}

func printJSON(path string) error {
	base := controlBase()
	if base != "" {
		resp, err := http.Get(base + path)
		if err != nil {
			return err
		}
		defer resp.Body.Close()
		b, err := io.ReadAll(resp.Body)
		if err != nil {
			return err
		}
		return printPretty(b)
	}
	return unixGET(paths.ControlSocket(), path)
}

func printPretty(b []byte) error {
	var pretty any
	if json.Unmarshal(b, &pretty) == nil {
		enc := json.NewEncoder(os.Stdout)
		enc.SetIndent("", "  ")
		return enc.Encode(pretty)
	}
	fmt.Println(string(b))
	return nil
}

func unixGET(sock, path string) error {
	client := &http.Client{
		Transport: &http.Transport{
			Dial: func(_, _ string) (net.Conn, error) {
				return net.DialTimeout("unix", sock, 2*time.Second)
			},
		},
		Timeout: 5 * time.Second,
	}
	resp, err := client.Get("http://unix" + path)
	if err != nil {
		return fmt.Errorf("control socket %s: %w", sock, err)
	}
	defer resp.Body.Close()
	b, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	return printPretty(b)
}

func systemctl(action, unit string) error {
	if runtime.GOOS == "windows" {
		return fmt.Errorf("%s not supported on windows via systemctl", action)
	}
	cmd := exec.Command("systemctl", action, unit)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

func journalctl(args []string) error {
	if runtime.GOOS == "windows" {
		return fmt.Errorf("logs not supported on windows")
	}
	a := []string{"-u", "nyxveil-server"}
	a = append(a, args...)
	cmd := exec.Command("journalctl", a...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	cmd.Stdin = os.Stdin
	return cmd.Run()
}

func runUpdate(args []string) error {
	if len(args) < 1 {
		return fmt.Errorf("usage: nyxveilctl update <manifest-url>")
	}
	bin, err := os.Executable()
	if err != nil {
		bin = paths.BinaryPath()
	}
	server := paths.BinaryPath()
	if _, err := os.Stat(server); err != nil {
		server = filepath.Join(filepath.Dir(bin), "nyxveil-server")
	}
	fmt.Printf("fetching update manifest %s (server binary %s)\n", args[0], server)
	resp, err := http.Get(args[0])
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	b, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil {
		return err
	}
	fmt.Printf("manifest bytes=%d — apply via internal/updater\n", len(b))
	return nil
}

func showConfig(args []string) error {
	path := paths.ServerConfig()
	if len(args) > 0 {
		path = args[0]
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	fmt.Println(string(b))
	return nil
}

func uninstall() error {
	if runtime.GOOS == "windows" {
		return fmt.Errorf("uninstall: use Windows installer / remove service manually")
	}
	_ = exec.Command("systemctl", "stop", "nyxveil-server").Run()
	_ = exec.Command("systemctl", "disable", "nyxveil-server").Run()
	_ = os.Remove(paths.ServiceUnit)
	fmt.Println("service stopped; remove /etc/nyxveil and /var/lib/nyxveil manually if desired")
	return nil
}
