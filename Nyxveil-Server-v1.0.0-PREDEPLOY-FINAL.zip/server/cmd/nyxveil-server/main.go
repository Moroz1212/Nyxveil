package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/nyxveil/server/internal/localconfig"
	"github.com/nyxveil/server/internal/paths"
	"github.com/nyxveil/server/internal/runtime"
	"github.com/nyxveil/server/internal/version"
)

func main() {
	configPath := flag.String("config", paths.ServerConfig(), "path to server.json")
	register := flag.String("register", "", "bootstrap token to register with Control Plane then exit")
	skipTUN := flag.Bool("skip-tun", false, "skip TUN/datapath (dev / unsupported OS)")
	controlHTTP := flag.String("control-http", "", "loopback HTTP control addr (Windows/tests); empty uses unix socket on Linux")
	showVersion := flag.Bool("version", false, "print version and exit")
	flag.Parse()

	if *showVersion {
		fmt.Printf("nyxveil-server %s (core %s, %s)\n", version.ServerVersion, version.CoreVersion, version.ProtocolVersion)
		return
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	if *register != "" {
		if err := doRegister(ctx, *configPath, *register); err != nil {
			log.Fatal(err)
		}
		return
	}

	node, err := runtime.New(runtime.Options{
		ConfigPath:  *configPath,
		SkipTUN:     *skipTUN,
		ControlHTTP: *controlHTTP,
	})
	if err != nil {
		log.Fatal(err)
	}
	if err := node.Start(ctx); err != nil {
		log.Fatal(err)
	}
	log.Printf("nyxveil-server %s running", version.ServerVersion)
	<-ctx.Done()
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	_ = node.Shutdown(shutdownCtx)
	log.Println("shutdown complete")
}

func doRegister(ctx context.Context, configPath, token string) error {
	// Ensure config exists with required fields.
	if _, err := localconfig.Load(configPath); err != nil {
		return err
	}
	node, err := runtime.New(runtime.Options{ConfigPath: configPath, SkipTUN: true})
	if err != nil {
		return err
	}
	resp, err := node.Register(ctx, token)
	if err != nil {
		return err
	}
	fmt.Printf("registered node_id=%s config_version=%d\n", resp.NodeID, resp.ConfigVersion)
	return nil
}
