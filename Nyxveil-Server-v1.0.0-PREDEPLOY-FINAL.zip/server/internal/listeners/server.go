// Package listeners accepts TLS and QUIC VPN connections.
package listeners

import (
	"context"
	"crypto/tls"
	"errors"
	"log"
	"sync"
	"sync/atomic"

	"github.com/nyxveil/nvp/core/auth/ticket"
	"github.com/nyxveil/nvp/core/authhandler"
	"github.com/nyxveil/nvp/core/control"
	"github.com/nyxveil/nvp/core/session"
	"github.com/nyxveil/nvp/core/transport"
	"github.com/nyxveil/nvp/core/transport/serverconfig"
	"github.com/nyxveil/server/internal/datapath"
	"github.com/nyxveil/server/internal/sessions"
)

// Config controls listener bind addresses and auth.
type Config struct {
	TLSAddr    string
	QUICAddr   string
	Cert       tls.Certificate
	NodeID     string
	LocationID string
	Verifier   ticket.VerifierConfig
	MTU        int
}

// Gate decides whether new sessions may be accepted.
type Gate interface {
	Accepting() bool
	Available() bool
}

// Server runs TLS+QUIC accept loops and wires sessions into the datapath.
type Server struct {
	cfg    Config
	gate   Gate
	mgr    *sessions.Manager
	bridge *datapath.Bridge
	auth   *authhandler.AuthHandler

	mu      sync.Mutex
	tlsLn   transport.Listener
	quicLn  transport.Listener
	cancel  context.CancelFunc
	wg      sync.WaitGroup
	running bool
	tlsOK   atomic.Bool
	quicOK  atomic.Bool
}

// New constructs a server (listeners not started until Start).
func New(cfg Config, gate Gate, mgr *sessions.Manager, bridge *datapath.Bridge) *Server {
	auth := authhandler.NewAuthHandler(cfg.NodeID, cfg.LocationID, cfg.Verifier)
	return &Server{
		cfg:    cfg,
		gate:   gate,
		mgr:    mgr,
		bridge: bridge,
		auth:   auth,
	}
}

// UpdateAuth refreshes node/location and verifier used for new connections.
func (s *Server) UpdateAuth(nodeID, locationID string, verifier ticket.VerifierConfig) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.cfg.NodeID = nodeID
	s.cfg.LocationID = locationID
	s.cfg.Verifier = verifier
	s.auth = authhandler.NewAuthHandler(nodeID, locationID, verifier)
}

// Start opens TLS and QUIC listeners and begins accept loops.
func (s *Server) Start(parent context.Context) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.running {
		return nil
	}
	ctx, cancel := context.WithCancel(parent)
	tlsAddr := s.cfg.TLSAddr
	if tlsAddr == "" {
		tlsAddr = ":443"
	}
	quicAddr := s.cfg.QUICAddr
	if quicAddr == "" {
		quicAddr = tlsAddr
	}

	quicLn, err := serverconfig.ListenQUIC(ctx, quicAddr, serverconfig.QUICServerConfig{Cert: s.cfg.Cert})
	if err != nil {
		cancel()
		return err
	}
	tlsLn, err := serverconfig.NewTLSListener(ctx, tlsAddr, serverconfig.TLSServerConfig{Cert: s.cfg.Cert})
	if err != nil {
		_ = quicLn.Close()
		cancel()
		return err
	}
	s.tlsLn = tlsLn
	s.quicLn = quicLn
	s.cancel = cancel
	s.running = true
	s.tlsOK.Store(true)
	s.quicOK.Store(true)

	s.wg.Add(2)
	go s.serveLoop(ctx, tlsLn, "tls")
	go s.serveLoop(ctx, quicLn, "quic")
	return nil
}

// Stop closes listeners and waits for accept loops.
func (s *Server) Stop() {
	s.mu.Lock()
	if !s.running {
		s.mu.Unlock()
		return
	}
	s.running = false
	cancel := s.cancel
	tlsLn, quicLn := s.tlsLn, s.quicLn
	s.tlsLn, s.quicLn = nil, nil
	s.mu.Unlock()
	if cancel != nil {
		cancel()
	}
	if tlsLn != nil {
		_ = tlsLn.Close()
	}
	if quicLn != nil {
		_ = quicLn.Close()
	}
	s.tlsOK.Store(false)
	s.quicOK.Store(false)
	s.wg.Wait()
}

// TLSOK reports whether the TLS listener is running.
func (s *Server) TLSOK() bool { return s.tlsOK.Load() }

// QUICOK reports whether the QUIC listener is running.
func (s *Server) QUICOK() bool { return s.quicOK.Load() }

func (s *Server) serveLoop(ctx context.Context, ln transport.Listener, label string) {
	defer s.wg.Done()
	for {
		conn, err := ln.Accept(ctx)
		if err != nil {
			select {
			case <-ctx.Done():
				return
			default:
				log.Printf("listeners: %s accept: %v", label, err)
				continue
			}
		}
		if s.gate != nil && (!s.gate.Accepting() || !s.gate.Available()) {
			_ = conn.Close()
			continue
		}
		go s.handleConn(ctx, conn)
	}
}

func (s *Server) handleConn(ctx context.Context, conn transport.Conn) {
	defer conn.Close()
	if s.gate != nil && (!s.gate.Accepting() || !s.gate.Available()) {
		return
	}

	cfg := session.DefaultConfig(false)
	if s.cfg.MTU > 0 {
		cfg.MTU = s.cfg.MTU
	}
	sess := session.New(cfg)

	s.mu.Lock()
	auth := s.auth
	s.mu.Unlock()

	sess.OnControl(func(msgType byte, payload []byte) error {
		if msgType == control.TypeAuth {
			return auth.HandleAuth(ctx, sess, payload)
		}
		return nil
	})

	if err := sess.Connect(ctx, conn); err != nil {
		return
	}
	if err := sess.RunHandshake(ctx); err != nil {
		return
	}
	// Wait for AUTH before allocating capacity / IP.
	if err := sess.WaitEstablished(ctx); err != nil {
		return
	}
	if s.gate != nil && (!s.gate.Accepting() || !s.gate.Available()) {
		_ = sess.Close(ctx)
		return
	}
	rec, err := s.mgr.Allocate(sess)
	if err != nil {
		_ = sess.Close(ctx)
		return
	}
	if s.bridge != nil {
		s.bridge.AttachSession(sess)
	}
	defer s.mgr.ReleaseBySession(sess)
	_ = rec
	_ = sess.ReadLoop(ctx)
}

// ErrNotRunning is returned when operations require a started server.
var ErrNotRunning = errors.New("listeners: not running")
