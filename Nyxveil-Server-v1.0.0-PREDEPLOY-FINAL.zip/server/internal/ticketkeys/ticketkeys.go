package ticketkeys

import (
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"os"
)

// File stores Control Plane Access Ticket verification public keys (never private).
// Provisioned at install from admin export until a public node JWKS endpoint exists.
type File struct {
	Issuer string            `json:"issuer"`
	Keys   map[string]string `json:"keys"` // kid -> base64 (std) 32-byte public key
}

func Load(path string) (issuer string, keys map[string]ed25519.PublicKey, err error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return "", nil, err
	}
	var f File
	if err := json.Unmarshal(b, &f); err != nil {
		return "", nil, err
	}
	out := make(map[string]ed25519.PublicKey, len(f.Keys))
	for kid, enc := range f.Keys {
		raw, err := base64.StdEncoding.DecodeString(enc)
		if err != nil {
			raw, err = base64.RawURLEncoding.DecodeString(enc)
		}
		if err != nil {
			return "", nil, fmt.Errorf("ticketkeys: key %q: %w", kid, err)
		}
		if len(raw) != ed25519.PublicKeySize {
			return "", nil, fmt.Errorf("ticketkeys: key %q: want %d bytes", kid, ed25519.PublicKeySize)
		}
		out[kid] = ed25519.PublicKey(raw)
	}
	issuer = f.Issuer
	if issuer == "" {
		issuer = "nyxveil-control-plane"
	}
	return issuer, out, nil
}
