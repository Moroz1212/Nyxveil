// Package runtime is the Nyxveil VPN node process lifecycle.
package runtime

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"errors"
	"fmt"
	"log"
	"math/big"
	"os"
	"path/filepath"
	"sync"
	"sync/atomic"
	"time"

	"github.com/nyxveil/nvp/core/auth/ticket"
	"github.com/nyxveil/server/internal/controlplane"
	"github.com/nyxveil/server/internal/controlsock"
	"github.com/nyxveil/server/internal/datapath"
	"github.com/nyxveil/server/internal/health"
	"github.com/nyxveil/server/internal/identity"
	"github.com/nyxveil/server/internal/listeners"
	"github.com/nyxveil/server/internal/localconfig"
	"github.com/nyxveil/server/internal/metrics"
	"github.com/nyxveil/server/internal/paths"
	"github.com/nyxveil/server/internal/revocation"
	"github.com/nyxveil/server/internal/sessions"
	"github.com/nyxveil/server/internal/ticketkeys"
	"github.com/nyxveil/server/internal/tun"
	"github.com/nyxveil/server/internal/version"
)

// Options configures Node construction.
type Options struct {
	ConfigPath   string
	KeyPath      string
	AppliedPath  string
	ControlSock  string
	ControlHTTP  string // Windows / test fallback
	SkipTUN      bool   // tests / Windows without TUN
	TicketIssuer string
	TicketAud    string
	CPPublicKeys map[string]ed25519.PublicKey
}

// Node is the main VPN node runtime.
type Node struct {
	opts Options

	mu       sync.RWMutex
	local    *localconfig.File
	applied  controlplane.NodeConfig
	key      *identity.NodeKey
	cp       *controlplane.Client
	sessions *sessions.Manager
	rev      *revocation.Cache
	bridge   *datapath.Bridge
	listen   *listeners.Server
	ctl      *controlsock.Server
	sampler  *metrics.Sampler
	tunDev   *tun.Device

	startedAt   time.Time
	running     atomic.Bool
	cpOK        atomic.Bool
	accepting   atomic.Bool
	enabled     atomic.Bool
	draining    atomic.Bool
	maintenance atomic.Bool

	cancel context.CancelFunc
	wg     sync.WaitGroup
}

// New loads identity and local config; does not start loops.
func New(opts Options) (*Node, error) {
	if opts.ConfigPath == "" {
		opts.ConfigPath = paths.ServerConfig()
	}
	if opts.KeyPath == "" {
		opts.KeyPath = paths.NodeKey()
	}
	if opts.AppliedPath == "" {
		opts.AppliedPath = paths.AppliedConfig()
	}
	if opts.ControlSock == "" {
		opts.ControlSock = paths.ControlSocket()
	}
	if opts.TicketIssuer == "" {
		opts.TicketIssuer = "nyxveil-control-plane"
	}
	if opts.TicketAud == "" {
		opts.TicketAud = "nvp-node"
	}

	cfg, err := localconfig.Load(opts.ConfigPath)
	if err != nil {
		return nil, err
	}

	// Optional ticket verification keys (Control Plane signing pubs).
	keysPath := filepath.Join(filepath.Dir(opts.KeyPath), "ticket-keys.json")
	if iss, keys, err := ticketkeys.Load(keysPath); err == nil {
		opts.TicketIssuer = iss
		opts.CPPublicKeys = keys
	}
	key, _, err := identity.LoadOrCreate(opts.KeyPath)
	if err != nil {
		return nil, err
	}
	cp, err := controlplane.NewClient(cfg.ControlPlaneURL, nil)
	if err != nil {
		return nil, err
	}
	cp.NodeID = cfg.NodeID
	cp.PrivateKey = key.Private

	capN := 100
	mgr, err := sessions.New(capN, cfg.VPNSubnetCIDR)
	if err != nil {
		return nil, err
	}
	n := &Node{
		opts:     opts,
		local:    cfg,
		key:      key,
		cp:       cp,
		sessions: mgr,
		rev:      revocation.New(),
		sampler:  metrics.NewSampler(),
	}
	n.enabled.Store(true)
	n.accepting.Store(true)
	if snap, err := localconfig.LoadApplied(opts.AppliedPath); err == nil {
		n.applied = snap.Config
		n.applyFlags(snap.Config)
		if snap.Config.Capacity > 0 {
			mgr.SetCapacity(snap.Config.Capacity)
		}
	}
	return n, nil
}

// Register bootstraps the node with Control Plane using a bootstrap token.
func (n *Node) Register(ctx context.Context, bootstrapToken string) (*controlplane.RegisterResponse, error) {
	n.mu.RLock()
	cfg := *n.local
	key := n.key
	n.mu.RUnlock()
	req := controlplane.RegisterRequest{
		BootstrapToken:  bootstrapToken,
		NodeID:          cfg.NodeID,
		LocationID:      cfg.LocationID,
		DisplayName:     cfg.DisplayName,
		PublicIdentity:  key.PublicIdentity(),
		PublicKey:       append([]byte(nil), key.Public...),
		ServerName:      cfg.ServerName,
		ProtocolVersion: version.ProtocolNumber,
		ServerVersion:   version.ServerVersion,
		Capacity:        n.sessions.Capacity(),
		Endpoints:       []controlplane.Endpoint{},
	}
	if cfg.ServerName == "" && cfg.PublicHost != "" {
		req.ServerName = cfg.PublicHost
	}
	if cert, err := n.loadTLSCert(cfg); err == nil {
		if pin, err := SPKIPinSHA256(cert); err == nil {
			req.SPKIPin = pin
		}
	}
	port := 443
	if cfg.PublicHost != "" {
		req.Endpoints = append(req.Endpoints, controlplane.Endpoint{
			Host: cfg.PublicHost, Port: port, AddressFamily: "hostname", Priority: 1, Enabled: true,
		})
	}
	resp, err := n.cp.Register(ctx, req)
	// Best-effort: do not retain bootstrap token beyond this call (caller should drop it).
	_ = bootstrapToken
	return resp, err
}

// Start runs heartbeat, revocation sync, listeners, datapath, and control socket.
func (n *Node) Start(parent context.Context) error {
	if n.running.Swap(true) {
		return errors.New("runtime: already running")
	}
	ctx, cancel := context.WithCancel(parent)
	n.cancel = cancel
	n.startedAt = time.Now()

	n.mu.RLock()
	cfg := *n.local
	n.mu.RUnlock()

	cert, err := n.loadTLSCert(cfg)
	if err != nil {
		n.running.Store(false)
		cancel()
		return err
	}

	mtu := 1420
	if n.applied.MTU != nil && *n.applied.MTU > 0 {
		mtu = *n.applied.MTU
	}

	var bridge *datapath.Bridge
	if !n.opts.SkipTUN {
		nodeAddr, err := sessions.NodeAddress(cfg.VPNSubnetCIDR)
		if err != nil {
			n.running.Store(false)
			cancel()
			return err
		}
		dev, err := tun.Open("nyxveil0", nodeAddr.String(), mtu)
		if err != nil {
			// On non-Linux, TUN is unsupported; allow control-plane-only mode with SkipTUN.
			log.Printf("runtime: TUN open failed (%v); continuing without datapath", err)
		} else {
			n.tunDev = dev
			bridge = datapath.New(n.sessions, dev, 64)
			if err := bridge.Start(ctx); err != nil {
				_ = dev.Close()
				n.running.Store(false)
				cancel()
				return err
			}
			n.bridge = bridge
		}
	}

	verifier := ticket.VerifierConfig{
		Issuer:     n.opts.TicketIssuer,
		Audience:   n.opts.TicketAud,
		PublicKeys: n.opts.CPPublicKeys,
		Revoked:    n.rev,
	}
	if verifier.PublicKeys == nil {
		verifier.PublicKeys = map[string]ed25519.PublicKey{}
	}

	lnCfg := listeners.Config{
		TLSAddr:    cfg.TLSListen,
		QUICAddr:   cfg.QUICListen,
		Cert:       cert,
		NodeID:     cfg.NodeID,
		LocationID: cfg.LocationID,
		Verifier:   verifier,
		MTU:        mtu,
	}
	srv := listeners.New(lnCfg, n, n.sessions, bridge)
	if n.Accepting() {
		if err := srv.Start(ctx); err != nil {
			n.Shutdown(context.Background())
			return fmt.Errorf("runtime: listeners: %w", err)
		}
	}
	n.listen = srv

	ctl := &controlsock.Server{
		SocketPath: n.opts.ControlSock,
		HTTPAddr:   n.opts.ControlHTTP,
		Status:     func() any { return n.Status() },
		Health: func() any {
			st := n.Status()
			return map[string]any{"healthy": st.Healthy, "running": st.Running}
		},
	}
	if err := ctl.Start(ctx); err != nil {
		log.Printf("runtime: control socket: %v", err)
	} else {
		n.ctl = ctl
	}

	n.wg.Add(1)
	go n.loop(ctx)
	return nil
}

// Accepting implements listeners.Gate.
func (n *Node) Accepting() bool {
	return n.accepting.Load() && n.enabled.Load() && !n.draining.Load() && !n.maintenance.Load()
}

// Available implements listeners.Gate.
func (n *Node) Available() bool {
	return n.sessions.Available()
}

// Shutdown stops listeners, datapath, and background loops.
func (n *Node) Shutdown(ctx context.Context) error {
	if !n.running.Swap(false) {
		return nil
	}
	if n.cancel != nil {
		n.cancel()
	}
	done := make(chan struct{})
	go func() {
		n.wg.Wait()
		close(done)
	}()
	select {
	case <-done:
	case <-ctx.Done():
	}
	if n.listen != nil {
		n.listen.Stop()
	}
	if n.bridge != nil {
		n.bridge.Stop()
	}
	if n.tunDev != nil {
		_ = n.tunDev.Close()
	}
	if n.ctl != nil {
		_ = n.ctl.Stop()
	}
	n.accepting.Store(false)
	return nil
}

// Status builds a health.Status snapshot.
func (n *Node) Status() health.Status {
	cpu, memPct, memBytes, _, _ := n.sampler.Sample()
	n.mu.RLock()
	cfg := *n.local
	applied := n.applied
	n.mu.RUnlock()
	st := health.Status{
		Running:         n.running.Load(),
		NodeID:          cfg.NodeID,
		LocationID:      cfg.LocationID,
		CPConnected:     n.cpOK.Load(),
		Sessions:        n.sessions.Count(),
		Capacity:        n.sessions.Capacity(),
		CPUUsage:        cpu,
		MemoryUsage:     memPct,
		MemoryBytes:     memBytes,
		ConfigVersion:   applied.ConfigVersion,
		Enabled:         n.enabled.Load(),
		Draining:        n.draining.Load(),
		MaintenanceMode: n.maintenance.Load(),
		Accepting:       n.Accepting(),
		RevocationStale: n.rev.Stale(),
	}
	if !n.startedAt.IsZero() {
		st.UptimeSeconds = int64(time.Since(n.startedAt).Seconds())
	}
	if n.listen != nil {
		st.TLSOK = n.listen.TLSOK()
		st.QUICOK = n.listen.QUICOK()
	}
	st.DefaultVersions()
	st.Healthy = st.Running && st.CPConnected && !st.RevocationStale && (st.TLSOK || st.QUICOK || n.opts.SkipTUN)
	return st
}

func (n *Node) loop(ctx context.Context) {
	defer n.wg.Done()
	hbSec := n.local.HeartbeatSec
	if hbSec <= 0 {
		hbSec = 30
	}
	hbTicker := time.NewTicker(time.Duration(hbSec) * time.Second)
	revTicker := time.NewTicker(60 * time.Second)
	defer hbTicker.Stop()
	defer revTicker.Stop()

	_ = n.syncRevocation(ctx)
	_ = n.heartbeat(ctx)

	for {
		select {
		case <-ctx.Done():
			return
		case <-hbTicker.C:
			_ = n.heartbeat(ctx)
		case <-revTicker.C:
			_ = n.syncRevocation(ctx)
		}
	}
}

func (n *Node) heartbeat(ctx context.Context) error {
	cpu, memPct, memBytes, rx, tx := n.sampler.Sample()
	up := int64(time.Since(n.startedAt).Seconds())
	healthy := true
	hb := controlplane.HeartbeatRequest{
		Capacity:        n.sessions.Capacity(),
		CurrentSessions: n.sessions.Count(),
		Load:            cpu / 100,
		CPUUsage:        &cpu,
		MemoryUsage:     &memPct,
		MemoryBytes:     &memBytes,
		Uptime:          &up,
		NetworkRxRate:   &rx,
		NetworkTxRate:   &tx,
		Healthy:         &healthy,
	}
	resp, err := n.cp.Heartbeat(ctx, hb)
	if err != nil {
		n.cpOK.Store(false)
		return err
	}
	n.cpOK.Store(true)
	n.mu.RLock()
	curVer := n.applied.ConfigVersion
	if curVer == 0 {
		curVer = n.local.ConfigVersion
	}
	n.mu.RUnlock()
	if resp.ConfigVersion > curVer {
		if err := n.pullAndApplyConfig(ctx); err != nil {
			log.Printf("runtime: config pull: %v", err)
		}
	}
	return nil
}

func (n *Node) syncRevocation(ctx context.Context) error {
	snap, err := n.cp.GetRevocation(ctx)
	if err != nil {
		return err
	}
	n.rev.Apply(*snap)
	return nil
}

func (n *Node) pullAndApplyConfig(ctx context.Context) error {
	cfg, err := n.cp.GetConfig(ctx)
	if err != nil {
		return err
	}
	return n.ApplyConfig(*cfg)
}

// ApplyConfig atomically applies a Control Plane node config.
func (n *Node) ApplyConfig(cfg controlplane.NodeConfig) error {
	n.mu.Lock()
	defer n.mu.Unlock()
	n.applied = cfg
	n.local.ConfigVersion = cfg.ConfigVersion
	if cfg.LocationID != "" {
		n.local.LocationID = cfg.LocationID
	}
	if cfg.Capacity > 0 {
		n.sessions.SetCapacity(cfg.Capacity)
	}
	n.applyFlags(cfg)
	_ = localconfig.SaveApplied(n.opts.AppliedPath, cfg)
	_ = n.local.Save(n.opts.ConfigPath)

	wasAccepting := n.Accepting()
	if n.listen != nil {
		n.listen.UpdateAuth(n.local.NodeID, n.local.LocationID, ticket.VerifierConfig{
			Issuer:     n.opts.TicketIssuer,
			Audience:   n.opts.TicketAud,
			PublicKeys: n.opts.CPPublicKeys,
			Revoked:    n.rev,
		})
		if wasAccepting && !n.Accepting() {
			// Draining/maintenance: stop accepting by closing listeners.
			// Existing sessions continue until natural close.
			go n.listen.Stop()
		}
	}
	return nil
}

func (n *Node) applyFlags(cfg controlplane.NodeConfig) {
	n.enabled.Store(cfg.Enabled || cfg.ConfigVersion == 0)
	n.draining.Store(cfg.Draining)
	n.maintenance.Store(cfg.MaintenanceMode)
	n.accepting.Store(n.enabled.Load() && !n.draining.Load() && !n.maintenance.Load())
}

func (n *Node) loadTLSCert(cfg localconfig.File) (tls.Certificate, error) {
	certFile := cfg.TLSCertFile
	keyFile := cfg.TLSKeyFile
	if certFile == "" {
		certFile = paths.TLSCert()
	}
	if keyFile == "" {
		keyFile = paths.TLSKey()
	}
	cert, err := tls.LoadX509KeyPair(certFile, keyFile)
	if err == nil {
		return cert, nil
	}
	if !errors.Is(err, os.ErrNotExist) && !os.IsNotExist(err) {
		// Fall through to generate if missing; otherwise return.
		if _, statErr := os.Stat(certFile); statErr == nil {
			return tls.Certificate{}, fmt.Errorf("runtime: load TLS cert: %w", err)
		}
	}
	serverName := cfg.ServerName
	if serverName == "" {
		serverName = cfg.PublicHost
	}
	if serverName == "" {
		serverName = "nyxveil-node"
	}
	log.Printf("runtime: generating self-signed TLS certificate for %s", serverName)
	if err := generateSelfSigned(certFile, keyFile, serverName); err != nil {
		return tls.Certificate{}, err
	}
	return tls.LoadX509KeyPair(certFile, keyFile)
}

func generateSelfSigned(certFile, keyFile, serverName string) error {
	if err := os.MkdirAll(filepath.Dir(certFile), 0o700); err != nil {
		return err
	}
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return err
	}
	tmpl := &x509.Certificate{
		SerialNumber: big.NewInt(1),
		NotBefore:    time.Now().Add(-time.Hour),
		NotAfter:     time.Now().Add(365 * 24 * time.Hour),
		KeyUsage:     x509.KeyUsageDigitalSignature | x509.KeyUsageKeyEncipherment,
		ExtKeyUsage:  []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		DNSNames:     []string{serverName},
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, pub, priv)
	if err != nil {
		return err
	}
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	keyDER, err := x509.MarshalPKCS8PrivateKey(priv)
	if err != nil {
		return err
	}
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: keyDER})
	if err := os.WriteFile(certFile, certPEM, 0o644); err != nil {
		return err
	}
	return os.WriteFile(keyFile, keyPEM, 0o600)
}

// SPKIPinSHA256 returns SHA-256 of the leaf certificate SPKI.
func SPKIPinSHA256(cert tls.Certificate) ([]byte, error) {
	if len(cert.Certificate) == 0 {
		return nil, errors.New("runtime: empty certificate")
	}
	parsed, err := x509.ParseCertificate(cert.Certificate[0])
	if err != nil {
		return nil, err
	}
	sum := sha256.Sum256(parsed.RawSubjectPublicKeyInfo)
	return sum[:], nil
}

// LoadCPPublicKeyPEM loads an Ed25519 public key from PEM for ticket verify.
func LoadCPPublicKeyPEM(path string) (ed25519.PublicKey, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	block, _ := pem.Decode(data)
	if block == nil {
		return nil, errors.New("runtime: no PEM block")
	}
	pub, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		return nil, err
	}
	ed, ok := pub.(ed25519.PublicKey)
	if !ok {
		return nil, errors.New("runtime: not ed25519")
	}
	return ed, nil
}
