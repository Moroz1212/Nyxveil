// Package health exposes node status for CLI and control socket.
package health

import (
	"github.com/nyxveil/server/internal/version"
)

// Status is a JSON-serializable node status snapshot (snake_case).
type Status struct {
	Running         bool    `json:"running"`
	Healthy         bool    `json:"healthy"`
	NodeID          string  `json:"node_id"`
	LocationID      string  `json:"location_id"`
	CPConnected     bool    `json:"cp_connected"`
	Sessions        int     `json:"sessions"`
	Capacity        int     `json:"capacity"`
	CPUUsage        float64 `json:"cpu_usage"`
	MemoryUsage     float64 `json:"memory_usage"`
	MemoryBytes     int64   `json:"memory_bytes"`
	ServerVersion   string  `json:"server_version"`
	CoreVersion     string  `json:"core_version"`
	ProtocolVersion string  `json:"protocol_version"`
	ConfigVersion   int64   `json:"config_version"`
	TLSOK           bool    `json:"tls_ok"`
	QUICOK          bool    `json:"quic_ok"`
	Accepting       bool    `json:"accepting"`
	Enabled         bool    `json:"enabled"`
	Draining        bool    `json:"draining"`
	MaintenanceMode bool    `json:"maintenance_mode"`
	UptimeSeconds   int64   `json:"uptime_seconds"`
	RevocationStale bool    `json:"revocation_stale"`
	Message         string  `json:"message,omitempty"`
}

// DefaultVersions fills version fields from the version package.
func (s *Status) DefaultVersions() {
	if s.ServerVersion == "" {
		s.ServerVersion = version.ServerVersion
	}
	if s.CoreVersion == "" {
		s.CoreVersion = version.CoreVersion
	}
	if s.ProtocolVersion == "" {
		s.ProtocolVersion = version.ProtocolVersion
	}
}
