// Package updater downloads and atomically replaces the nyxveil-server binary.
//
// Manifest JSON (snake_case):
//
//	{
//	  "version": "1.0.1",
//	  "arch": "linux/amd64",
//	  "sha256": "<hex>",
//	  "url": "https://...",
//	  "min_core": "1.0.0",
//	  "min_protocol": 1,
//	  "signature": "<base64 raw Ed25519 signature over canonical manifest bytes>"
//	}
//
// Signature covers CanonicalManifestBytes (sorted key material without the
// signature field). Verify with the embedded UpdatePublicKey placeholder —
// replace before production shipping.
package updater

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

// UpdatePublicKey is the Ed25519 public key that verifies release manifests.
// PLACEHOLDER: replace with the real Nyxveil update-signing public key before
// enabling production auto-updates. All-zero key rejects all manifests.
var UpdatePublicKey = ed25519.PublicKey(make([]byte, ed25519.PublicKeySize))

// Manifest describes a published node binary release.
type Manifest struct {
	Version     string `json:"version"`
	Arch        string `json:"arch"`
	SHA256      string `json:"sha256"`
	URL         string `json:"url"`
	MinCore     string `json:"min_core"`
	MinProtocol uint16 `json:"min_protocol"`
	Signature   string `json:"signature"`
}

// HealthCheck is invoked after replace; false triggers rollback.
type HealthCheck func() bool

// Updater performs download → verify → atomic replace → health/rollback.
type Updater struct {
	HTTP       *http.Client
	PublicKey  ed25519.PublicKey
	BinaryPath string
	PrevPath   string
	MarkerPath string
}

// New returns an updater with default HTTP client and embedded public key.
func New(binaryPath, prevPath, markerPath string) *Updater {
	return &Updater{
		HTTP:       &http.Client{Timeout: 5 * time.Minute},
		PublicKey:  UpdatePublicKey,
		BinaryPath: binaryPath,
		PrevPath:   prevPath,
		MarkerPath: markerPath,
	}
}

// ParseManifest unmarshals and verifies signature + SHA field format.
func ParseManifest(data []byte, pub ed25519.PublicKey) (*Manifest, error) {
	var m Manifest
	if err := json.Unmarshal(data, &m); err != nil {
		return nil, err
	}
	if m.Version == "" || m.SHA256 == "" || m.URL == "" {
		return nil, fmt.Errorf("updater: manifest missing required fields")
	}
	if pub == nil {
		pub = UpdatePublicKey
	}
	if isZeroKey(pub) {
		return nil, fmt.Errorf("updater: update public key is placeholder; refusing")
	}
	sig, err := base64.RawURLEncoding.DecodeString(m.Signature)
	if err != nil {
		sig, err = base64.StdEncoding.DecodeString(m.Signature)
		if err != nil {
			return nil, fmt.Errorf("updater: bad signature encoding: %w", err)
		}
	}
	msg := CanonicalManifestBytes(&m)
	if !ed25519.Verify(pub, msg, sig) {
		return nil, fmt.Errorf("updater: manifest signature invalid")
	}
	if _, err := hex.DecodeString(strings.TrimSpace(m.SHA256)); err != nil {
		return nil, fmt.Errorf("updater: bad sha256 hex: %w", err)
	}
	return &m, nil
}

// CanonicalManifestBytes builds the signed payload (no signature field).
func CanonicalManifestBytes(m *Manifest) []byte {
	type signed struct {
		Version     string `json:"version"`
		Arch        string `json:"arch"`
		SHA256      string `json:"sha256"`
		URL         string `json:"url"`
		MinCore     string `json:"min_core"`
		MinProtocol uint16 `json:"min_protocol"`
	}
	b, _ := json.Marshal(signed{
		Version:     m.Version,
		Arch:        m.Arch,
		SHA256:      m.SHA256,
		URL:         m.URL,
		MinCore:     m.MinCore,
		MinProtocol: m.MinProtocol,
	})
	return b
}

// ArchString returns GOOS/GOARCH for manifest matching.
func ArchString() string {
	return runtime.GOOS + "/" + runtime.GOARCH
}

// Apply downloads the manifest URL binary, verifies SHA-256, replaces atomically,
// runs health, and rolls back on failure.
func (u *Updater) Apply(m *Manifest, health HealthCheck) error {
	if m == nil {
		return fmt.Errorf("updater: nil manifest")
	}
	wantArch := ArchString()
	if m.Arch != "" && m.Arch != wantArch {
		return fmt.Errorf("updater: arch mismatch have %s want %s", wantArch, m.Arch)
	}
	tmpDir, err := os.MkdirTemp("", "nyxveil-update-*")
	if err != nil {
		return err
	}
	defer os.RemoveAll(tmpDir)
	tmpBin := filepath.Join(tmpDir, "nyxveil-server.new")
	if err := u.download(m.URL, tmpBin); err != nil {
		return err
	}
	sum, err := fileSHA256(tmpBin)
	if err != nil {
		return err
	}
	if !strings.EqualFold(sum, strings.TrimSpace(m.SHA256)) {
		return fmt.Errorf("updater: sha256 mismatch")
	}
	if err := os.Chmod(tmpBin, 0o755); err != nil {
		return err
	}
	if u.BinaryPath == "" {
		return fmt.Errorf("updater: empty binary path")
	}
	if err := os.MkdirAll(filepath.Dir(u.BinaryPath), 0o755); err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(u.PrevPath), 0o755); err != nil {
		return err
	}
	// Backup current binary.
	if _, err := os.Stat(u.BinaryPath); err == nil {
		_ = os.Remove(u.PrevPath)
		if err := copyFile(u.BinaryPath, u.PrevPath); err != nil {
			return fmt.Errorf("updater: backup: %w", err)
		}
	}
	if u.MarkerPath != "" {
		_ = os.WriteFile(u.MarkerPath, []byte(m.Version), 0o644)
	}
	if err := atomicReplace(tmpBin, u.BinaryPath); err != nil {
		return err
	}
	if health != nil && !health() {
		if err := u.Rollback(); err != nil {
			return fmt.Errorf("updater: health failed and rollback failed: %w", err)
		}
		return fmt.Errorf("updater: health check failed; rolled back")
	}
	if u.MarkerPath != "" {
		_ = os.Remove(u.MarkerPath)
	}
	return nil
}

// Rollback restores PrevPath over BinaryPath.
func (u *Updater) Rollback() error {
	if u.PrevPath == "" {
		return fmt.Errorf("updater: no previous binary path")
	}
	if _, err := os.Stat(u.PrevPath); err != nil {
		return fmt.Errorf("updater: previous binary missing: %w", err)
	}
	if err := atomicReplace(u.PrevPath, u.BinaryPath); err != nil {
		return err
	}
	if u.MarkerPath != "" {
		_ = os.Remove(u.MarkerPath)
	}
	return nil
}

func (u *Updater) download(url, dest string) error {
	resp, err := u.HTTP.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("updater: download status %d", resp.StatusCode)
	}
	f, err := os.OpenFile(dest, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o755)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = io.Copy(f, io.LimitReader(resp.Body, 256<<20))
	return err
}

func fileSHA256(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

func atomicReplace(src, dest string) error {
	dir := filepath.Dir(dest)
	tmp := filepath.Join(dir, ".nyxveil-replace-"+filepath.Base(dest))
	if err := copyFile(src, tmp); err != nil {
		return err
	}
	if err := os.Chmod(tmp, 0o755); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	if err := os.Rename(tmp, dest); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	return nil
}

func copyFile(src, dest string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.OpenFile(dest, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o755)
	if err != nil {
		return err
	}
	defer out.Close()
	if _, err := io.Copy(out, in); err != nil {
		return err
	}
	return out.Sync()
}

func isZeroKey(pub ed25519.PublicKey) bool {
	for _, b := range pub {
		if b != 0 {
			return false
		}
	}
	return true
}

// SignManifest is a test/helper that signs CanonicalManifestBytes with priv.
func SignManifest(m *Manifest, priv ed25519.PrivateKey) {
	m.Signature = base64.RawURLEncoding.EncodeToString(ed25519.Sign(priv, CanonicalManifestBytes(m)))
}
