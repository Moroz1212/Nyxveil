# Nyxveil Server (VPN Node)

Production Linux node for Nyxveil — registers with Control Plane, terminates TLS/QUIC, and bridges client traffic over TUN.

## One-command install (Ubuntu 24.04)

```bash
curl -fsSL https://raw.githubusercontent.com/Moroz1212/Nyxveil/main/server/installer/install.sh | sudo bash
```

The installer prompts for Control Plane URL, location, display name, and bootstrap token (`read -s`). Token is never written to disk.

With flags:

```bash
curl -fsSL https://raw.githubusercontent.com/Moroz1212/Nyxveil/main/server/installer/install.sh | sudo bash -s -- \
  --control-plane https://control.example.com \
  --location hel-1 \
  --name "hel-edge-01" \
  --public-host vpn.example.com
```

## Offline / local binary-dir

Build or unpack a release, then:

```bash
sudo ./installer/install.sh \
  --binary-dir ./dist/linux-amd64 \
  --skip-download \
  --control-plane https://control.example.com \
  --location hel-1 \
  --name "hel-edge-01" \
  --bootstrap-token "$TOKEN"
```

No Go toolchain is required on the VPS.

## Paths

| Path | Purpose |
|------|---------|
| `/etc/nyxveil/server.json` | Non-secret config |
| `/var/lib/nyxveil/` | `node.key`, TLS material, applied config |
| `/run/nyxveil/` | Control socket |
| `/usr/local/sbin/` | `nyxveil-server`, `nyxveilctl` |

## Binaries

- `cmd/nyxveil-server` — node daemon; `nyxveil-server --register TOKEN` for Control Plane bootstrap
- `cmd/nyxveilctl` — status/health/start/stop/logs

After install: `serv_status`, `serv_health`, `serv_logs -f`, …

## Docs

See [docs/](docs/) — start with [INSTALL.md](docs/INSTALL.md) and [ARCHITECTURE.md](docs/ARCHITECTURE.md).

Frozen Protocol Core notes: [THIRD_PARTY_CORE.md](THIRD_PARTY_CORE.md).

## Module

```
github.com/nyxveil/server
```
